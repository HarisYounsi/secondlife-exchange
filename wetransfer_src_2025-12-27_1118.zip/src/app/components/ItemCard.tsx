import React from 'react';
import { Card, CardContent, CardFooter, CardHeader } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { ThumbsUp, MessageCircle } from 'lucide-react';
import { Item } from '../data/items';

interface ItemCardProps {
  item: Item;
  onVote?: (itemId: string) => void;
  onContact?: (item: Item) => void;
}

const conditionColors = {
  excellent: 'bg-green-100 text-green-800',
  good: 'bg-blue-100 text-blue-800',
  fair: 'bg-yellow-100 text-yellow-800'
};

const conditionLabels = {
  excellent: 'Excellent',
  good: 'Bon',
  fair: 'Correct'
};

export const ItemCard: React.FC<ItemCardProps> = ({ item, onVote, onContact }) => {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="aspect-square overflow-hidden bg-gray-100">
        <img 
          src={item.image} 
          alt={item.title}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
        />
      </div>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-semibold line-clamp-1">{item.title}</h3>
          <Badge className={conditionColors[item.condition]}>
            {conditionLabels[item.condition]}
          </Badge>
        </div>
        <p className="text-sm text-gray-600 line-clamp-2 mt-1">
          {item.description}
        </p>
      </CardHeader>
      <CardContent className="pb-3">
        <div className="flex items-center gap-2">
          <Avatar className="w-8 h-8">
            <AvatarImage src={item.userAvatar} alt={item.userName} />
            <AvatarFallback>{item.userName.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm truncate">{item.userName}</p>
            <p className="text-xs text-gray-500">
              {new Date(item.createdAt).toLocaleDateString('fr-FR')}
            </p>
          </div>
        </div>
      </CardContent>
      <CardFooter className="pt-3 border-t flex gap-2">
        <Button 
          variant="outline" 
          size="sm" 
          className="flex-1"
          onClick={() => onVote?.(item.id)}
        >
          <ThumbsUp className="w-4 h-4 mr-1" />
          {item.votes}
        </Button>
        <Button 
          variant="default" 
          size="sm" 
          className="flex-1 bg-emerald-600 hover:bg-emerald-700"
          onClick={() => onContact?.(item)}
        >
          <MessageCircle className="w-4 h-4 mr-1" />
          Contacter
        </Button>
      </CardFooter>
    </Card>
  );
};
