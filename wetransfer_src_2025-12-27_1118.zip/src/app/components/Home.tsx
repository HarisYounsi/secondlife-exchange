import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Calendar, TrendingUp, Users, Leaf, ArrowRight } from 'lucide-react';

interface HomeProps {
  setActiveTab: (tab: string) => void;
}

export const Home: React.FC<HomeProps> = ({ setActiveTab }) => {
  const stats = [
    { label: 'Objets échangés', value: '12,547', icon: TrendingUp, color: 'text-emerald-600' },
    { label: 'Membres actifs', value: '3,241', icon: Users, color: 'text-blue-600' },
    { label: 'Thèmes disponibles', value: '52', icon: Calendar, color: 'text-purple-600' },
    { label: 'CO₂ économisé', value: '8.5T', icon: Leaf, color: 'text-green-600' },
  ];

  const currentTheme = {
    name: 'Électronique et Gadgets',
    description: 'Échangez vos appareils électroniques et découvrez de nouveaux gadgets',
    endsIn: '3 jours',
    participants: 247,
    itemsAvailable: 89,
  };

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl p-8 md:p-12 text-white">
        <div className="max-w-3xl">
          <Badge className="bg-white/20 text-white border-white/30 mb-4">
            Économie Circulaire
          </Badge>
          <h1 className="text-4xl md:text-5xl mb-4">
            Échangez, Partagez, Préservez
          </h1>
          <p className="text-lg text-emerald-50 mb-6">
            Rejoignez notre communauté et participez à un mouvement pour une consommation plus responsable. 
            Chaque semaine, un nouveau thème d'échange pour donner une seconde vie à vos objets.
          </p>
          <Button 
            size="lg" 
            className="bg-white text-emerald-600 hover:bg-emerald-50"
            onClick={() => setActiveTab('themes')}
          >
            Découvrir le thème de la semaine
            <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </div>
      </section>

      {/* Stats Grid */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label}>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">{stat.label}</p>
                    <p className="text-3xl mt-1">{stat.value}</p>
                  </div>
                  <div className={`p-3 rounded-full bg-gray-100 ${stat.color}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </section>

      {/* Current Theme Highlight */}
      <section>
        <Card className="border-2 border-emerald-200 bg-gradient-to-br from-emerald-50 to-white">
          <CardHeader>
            <div className="flex items-center justify-between">
              <Badge className="bg-emerald-500">Thème actuel</Badge>
              <span className="text-sm text-gray-600">Se termine dans {currentTheme.endsIn}</span>
            </div>
            <CardTitle className="text-2xl mt-4">{currentTheme.name}</CardTitle>
            <CardDescription className="text-base">
              {currentTheme.description}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-6 mb-4">
              <div>
                <p className="text-sm text-gray-600">Participants</p>
                <p className="text-xl">{currentTheme.participants}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Objets disponibles</p>
                <p className="text-xl">{currentTheme.itemsAvailable}</p>
              </div>
            </div>
            <Button 
              className="bg-emerald-600 hover:bg-emerald-700"
              onClick={() => setActiveTab('themes')}
            >
              Participer maintenant
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </CardContent>
        </Card>
      </section>

      {/* Educational Section Preview */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl">En savoir plus</h2>
          <Button variant="ghost" onClick={() => setActiveTab('discover')}>
            Voir tout
            <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader>
              <CardTitle>L'impact de l'électronique</CardTitle>
              <CardDescription>
                Découvrez comment réduire les déchets électroniques
              </CardDescription>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Économie circulaire</CardTitle>
              <CardDescription>
                Les principes d'une consommation responsable
              </CardDescription>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Guide de réparation</CardTitle>
              <CardDescription>
                Apprenez à réparer plutôt que jeter
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </section>
    </div>
  );
};
