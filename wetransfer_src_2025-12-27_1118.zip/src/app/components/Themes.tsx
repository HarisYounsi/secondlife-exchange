import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Separator } from './ui/separator';
import { ItemCard } from './ItemCard';
import { AddItemDialog } from './AddItemDialog';
import { themes, getCurrentTheme, getUpcomingThemes } from '../data/themes';
import { mockItems, getItemsByTheme, Item } from '../data/items';
import { Plus, Calendar, TrendingUp, Leaf, Clock } from 'lucide-react';
import { Laptop, Shirt, Book, Sofa, Bike } from 'lucide-react';
import { toast } from 'sonner';

const iconMap: Record<string, any> = {
  Laptop,
  Shirt,
  Book,
  Sofa,
  Bike
};

export const Themes: React.FC = () => {
  const [addItemDialogOpen, setAddItemDialogOpen] = useState(false);
  const [items, setItems] = useState<Item[]>(mockItems);
  const [votedItems, setVotedItems] = useState<Set<string>>(new Set());
  
  const currentTheme = getCurrentTheme();
  const upcomingThemes = getUpcomingThemes();
  const currentThemeItems = getItemsByTheme(currentTheme.id);

  const getDaysRemaining = (endDate: string) => {
    const end = new Date(endDate);
    const today = new Date();
    const diffTime = end.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const handleVote = (itemId: string) => {
    if (votedItems.has(itemId)) {
      toast.info('Vous avez déjà voté pour cet objet');
      return;
    }

    setItems(items.map(item => 
      item.id === itemId ? { ...item, votes: item.votes + 1 } : item
    ));
    setVotedItems(new Set(votedItems).add(itemId));
    toast.success('Vote enregistré !');
  };

  const handleContact = (item: Item) => {
    toast.success(`Demande de contact envoyée à ${item.userName}`);
  };

  const ThemeIcon = iconMap[currentTheme.icon] || Calendar;

  return (
    <div className="space-y-8">
      {/* Current Theme Hero */}
      <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 p-8 md:p-12 text-white">
        <div className="relative z-10">
          <Badge className="bg-white/20 text-white border-white/30 mb-4">
            Thème de la semaine
          </Badge>
          <div className="flex items-start gap-4 mb-4">
            <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
              <ThemeIcon className="w-8 h-8" />
            </div>
            <div className="flex-1">
              <h1 className="text-3xl md:text-4xl mb-2">
                {currentTheme.name}
              </h1>
              <p className="text-lg text-blue-50 mb-4">
                {currentTheme.description}
              </p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <Clock className="w-5 h-5 mb-2" />
              <p className="text-sm opacity-90">Se termine dans</p>
              <p className="text-2xl">{getDaysRemaining(currentTheme.endDate)} jours</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <TrendingUp className="w-5 h-5 mb-2" />
              <p className="text-sm opacity-90">Objets disponibles</p>
              <p className="text-2xl">{currentThemeItems.length}</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <Leaf className="w-5 h-5 mb-2" />
              <p className="text-sm opacity-90">CO₂ économisé</p>
              <p className="text-2xl">{currentTheme.impact.co2Saved}</p>
            </div>
          </div>

          <Button 
            size="lg" 
            className="bg-white text-blue-600 hover:bg-blue-50"
            onClick={() => setAddItemDialogOpen(true)}
          >
            <Plus className="w-5 h-5 mr-2" />
            Proposer un objet
          </Button>
        </div>
      </section>

      {/* Impact Information */}
      <Card className="border-2 border-emerald-200 bg-gradient-to-br from-emerald-50 to-white">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Leaf className="w-5 h-5 text-emerald-600" />
            <CardTitle>Impact écologique de ce thème</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-gray-700">{currentTheme.impact.description}</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center gap-3 p-4 bg-white rounded-lg">
              <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                <Leaf className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">CO₂ économisé</p>
                <p className="text-lg">{currentTheme.impact.co2Saved}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-white rounded-lg">
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Déchets réduits</p>
                <p className="text-lg">{currentTheme.impact.wasteReduced}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Items Tabs */}
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="all">Tous les objets ({currentThemeItems.length})</TabsTrigger>
          <TabsTrigger value="popular">Les plus populaires</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {currentThemeItems.map(item => (
              <ItemCard 
                key={item.id} 
                item={item}
                onVote={handleVote}
                onContact={handleContact}
              />
            ))}
          </div>
          {currentThemeItems.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500 mb-4">Aucun objet proposé pour le moment</p>
              <Button 
                className="bg-emerald-600 hover:bg-emerald-700"
                onClick={() => setAddItemDialogOpen(true)}
              >
                <Plus className="w-4 h-4 mr-2" />
                Soyez le premier à proposer un objet
              </Button>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="popular" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...currentThemeItems]
              .sort((a, b) => b.votes - a.votes)
              .slice(0, 6)
              .map(item => (
                <ItemCard 
                  key={item.id} 
                  item={item}
                  onVote={handleVote}
                  onContact={handleContact}
                />
              ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Upcoming Themes */}
      <section>
        <h2 className="text-2xl mb-6 flex items-center gap-2">
          <Calendar className="w-6 h-6 text-emerald-600" />
          Thèmes à venir
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {upcomingThemes.slice(0, 3).map(theme => {
            const Icon = iconMap[theme.icon] || Calendar;
            return (
              <Card key={theme.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <div className={`p-2 rounded-lg bg-${theme.color}-100`}>
                      <Icon className={`w-5 h-5 text-${theme.color}-600`} />
                    </div>
                    <Badge variant="outline">
                      {new Date(theme.startDate).toLocaleDateString('fr-FR', { 
                        day: 'numeric', 
                        month: 'short' 
                      })}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl">{theme.name}</CardTitle>
                  <CardDescription>{theme.description}</CardDescription>
                </CardHeader>
              </Card>
            );
          })}
        </div>
      </section>

      <AddItemDialog 
        open={addItemDialogOpen}
        onOpenChange={setAddItemDialogOpen}
        themeId={currentTheme.id}
        onItemAdded={() => {
          toast.success('Votre objet sera visible après validation');
        }}
      />
    </div>
  );
};
