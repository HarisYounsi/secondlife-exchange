import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  articles, 
  statistics, 
  repairTips, 
  getArticlesByCategory,
  Article 
} from '../data/educational';
import { 
  BookOpen, 
  TrendingUp, 
  Wrench, 
  Lightbulb, 
  Leaf, 
  FileVideo,
  Clock,
  ExternalLink
} from 'lucide-react';

export const Discover: React.FC = () => {
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  const categoryIcons: Record<string, any> = {
    environment: Leaf,
    repair: Wrench,
    stats: TrendingUp,
    tips: Lightbulb
  };

  const categoryLabels: Record<string, string> = {
    environment: 'Environnement',
    repair: 'Réparation',
    stats: 'Statistiques',
    tips: 'Conseils'
  };

  const categoryColors: Record<string, string> = {
    environment: 'bg-green-100 text-green-800',
    repair: 'bg-blue-100 text-blue-800',
    stats: 'bg-purple-100 text-purple-800',
    tips: 'bg-amber-100 text-amber-800'
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-4xl mb-2">Centre de Découverte</h1>
        <p className="text-lg text-gray-600">
          Apprenez-en plus sur l'économie circulaire et l'impact de vos échanges
        </p>
      </div>

      {/* Hero Stats */}
      <section className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl p-8 md:p-12 text-white">
        <h2 className="text-3xl mb-6">Pourquoi l'économie circulaire ?</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {statistics.slice(0, 3).map((stat, index) => (
            <div key={index} className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
              <p className="text-4xl mb-2">{stat.value}</p>
              <p className="text-lg mb-2">{stat.label}</p>
              <p className="text-sm text-emerald-100">{stat.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Articles Section */}
      <section>
        <Tabs defaultValue="all" className="w-full">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl flex items-center gap-2">
              <BookOpen className="w-6 h-6 text-emerald-600" />
              Articles et Ressources
            </h2>
          </div>
          
          <TabsList className="grid w-full max-w-2xl grid-cols-5">
            <TabsTrigger value="all">Tous</TabsTrigger>
            <TabsTrigger value="environment">
              <Leaf className="w-4 h-4 md:mr-2" />
              <span className="hidden md:inline">Environnement</span>
            </TabsTrigger>
            <TabsTrigger value="repair">
              <Wrench className="w-4 h-4 md:mr-2" />
              <span className="hidden md:inline">Réparation</span>
            </TabsTrigger>
            <TabsTrigger value="stats">
              <TrendingUp className="w-4 h-4 md:mr-2" />
              <span className="hidden md:inline">Stats</span>
            </TabsTrigger>
            <TabsTrigger value="tips">
              <Lightbulb className="w-4 h-4 md:mr-2" />
              <span className="hidden md:inline">Conseils</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {articles.map(article => {
                const Icon = categoryIcons[article.category];
                return (
                  <Card key={article.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="aspect-video overflow-hidden bg-gray-100">
                      <img 
                        src={article.image} 
                        alt={article.title}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <CardHeader>
                      <div className="flex items-center justify-between mb-2">
                        <Badge className={categoryColors[article.category]}>
                          <Icon className="w-3 h-3 mr-1" />
                          {categoryLabels[article.category]}
                        </Badge>
                        <span className="text-xs text-gray-500 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {article.readTime}
                        </span>
                      </div>
                      <CardTitle className="text-lg">{article.title}</CardTitle>
                      <CardDescription>{article.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button variant="outline" className="w-full" onClick={() => setSelectedArticle(article)}>
                        Lire l'article
                        <ExternalLink className="w-4 h-4 ml-2" />
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          {['environment', 'repair', 'stats', 'tips'].map(category => (
            <TabsContent key={category} value={category} className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {getArticlesByCategory(category).map(article => {
                  const Icon = categoryIcons[article.category];
                  return (
                    <Card key={article.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                      <div className="aspect-video overflow-hidden bg-gray-100">
                        <img 
                          src={article.image} 
                          alt={article.title}
                          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                      <CardHeader>
                        <div className="flex items-center justify-between mb-2">
                          <Badge className={categoryColors[article.category]}>
                            <Icon className="w-3 h-3 mr-1" />
                            {categoryLabels[article.category]}
                          </Badge>
                          <span className="text-xs text-gray-500 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {article.readTime}
                          </span>
                        </div>
                        <CardTitle className="text-lg">{article.title}</CardTitle>
                        <CardDescription>{article.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Button variant="outline" className="w-full">
                          Lire l'article
                          <ExternalLink className="w-4 h-4 ml-2" />
                        </Button>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </section>

      {/* Repair Tips */}
      <section>
        <h2 className="text-2xl mb-6 flex items-center gap-2">
          <Wrench className="w-6 h-6 text-emerald-600" />
          Conseils d'entretien par catégorie
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {repairTips.map((category, index) => (
            <Card key={index}>
              <CardHeader>
                <CardTitle>{category.category}</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {category.tips.map((tip, tipIndex) => (
                    <li key={tipIndex} className="flex items-start gap-2">
                      <Lightbulb className="w-4 h-4 text-amber-500 mt-1 flex-shrink-0" />
                      <span className="text-sm text-gray-700">{tip}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Statistics Grid */}
      <section>
        <h2 className="text-2xl mb-6 flex items-center gap-2">
          <TrendingUp className="w-6 h-6 text-emerald-600" />
          Statistiques clés
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {statistics.map((stat, index) => (
            <Card key={index} className="border-l-4 border-l-emerald-500">
              <CardHeader>
                <CardTitle className="text-3xl text-emerald-600">{stat.value}</CardTitle>
                <CardDescription className="text-base font-medium text-gray-900">
                  {stat.label}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-2">{stat.description}</p>
                <p className="text-xs text-gray-500 italic">Source: {stat.source}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Video Resources */}
      <section>
        <h2 className="text-2xl mb-6 flex items-center gap-2">
          <FileVideo className="w-6 h-6 text-emerald-600" />
          Ressources vidéo
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="overflow-hidden">
            <div className="aspect-video bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center">
              <FileVideo className="w-16 h-16 text-blue-500" />
            </div>
            <CardHeader>
              <CardTitle>Introduction à l'économie circulaire</CardTitle>
              <CardDescription>
                Découvrez les principes fondamentaux de l'économie circulaire en 10 minutes
              </CardDescription>
            </CardHeader>
          </Card>
          
          <Card className="overflow-hidden">
            <div className="aspect-video bg-gradient-to-br from-green-100 to-emerald-100 flex items-center justify-center">
              <FileVideo className="w-16 h-16 text-green-500" />
            </div>
            <CardHeader>
              <CardTitle>Comment réparer vos appareils électroniques</CardTitle>
              <CardDescription>
                Guide pratique pour prolonger la vie de vos smartphones et tablettes
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </section>
    </div>
  );
};
