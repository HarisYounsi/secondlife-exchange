import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Separator } from './ui/separator';
import { getUserExchanges, getUserStats } from '../data/exchanges';
import { Calendar, TrendingUp, Leaf, Award, Package, Clock } from 'lucide-react';

export const Profile: React.FC = () => {
  const { user } = useAuth();
  const exchanges = getUserExchanges(user?.id || '1');
  const stats = getUserStats();

  const completedExchanges = exchanges.filter(e => e.status === 'completed');
  const pendingExchanges = exchanges.filter(e => e.status === 'pending');

  return (
    <div className="space-y-8">
      {/* Profile Header */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-6">
            <Avatar className="w-24 h-24">
              <AvatarImage src={user?.avatar} alt={user?.name} />
              <AvatarFallback className="bg-emerald-500 text-white text-3xl">
                {user?.name.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h1 className="text-3xl mb-1">{user?.name}</h1>
                  <p className="text-gray-600">{user?.email}</p>
                </div>
                <Badge className="bg-emerald-100 text-emerald-800 border-emerald-200">
                  Membre actif
                </Badge>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600 mt-4">
                <Calendar className="w-4 h-4" />
                <span>Membre depuis {new Date(user?.joinedDate || '').toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Échanges réalisés</p>
                <p className="text-3xl mt-1">{stats.totalExchanges}</p>
              </div>
              <div className="p-3 rounded-full bg-blue-100 text-blue-600">
                <TrendingUp className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">En cours</p>
                <p className="text-3xl mt-1">{stats.pendingExchanges}</p>
              </div>
              <div className="p-3 rounded-full bg-amber-100 text-amber-600">
                <Clock className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Score Éco</p>
                <p className="text-3xl mt-1">{stats.ecoScore}</p>
              </div>
              <div className="p-3 rounded-full bg-green-100 text-green-600">
                <Award className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">CO₂ économisé</p>
                <p className="text-3xl mt-1">{stats.co2Saved}kg</p>
              </div>
              <div className="p-3 rounded-full bg-emerald-100 text-emerald-600">
                <Leaf className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Exchange History */}
      <Card>
        <CardHeader>
          <CardTitle>Historique des échanges</CardTitle>
          <CardDescription>
            Consultez tous vos échanges passés et en cours
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="completed" className="w-full">
            <TabsList className="grid w-full max-w-md grid-cols-2">
              <TabsTrigger value="completed">
                Réalisés ({completedExchanges.length})
              </TabsTrigger>
              <TabsTrigger value="pending">
                En cours ({pendingExchanges.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="completed" className="mt-6">
              <div className="space-y-4">
                {completedExchanges.map((exchange) => (
                  <div key={exchange.id} className="flex items-center gap-4 p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="flex items-center gap-3 flex-1">
                      <img 
                        src={exchange.itemOffered.image} 
                        alt={exchange.itemOffered.title}
                        className="w-16 h-16 rounded-lg object-cover"
                      />
                      <div className="flex-1">
                        <p className="font-medium">{exchange.itemOffered.title}</p>
                        <p className="text-sm text-gray-600">échangé contre</p>
                        <p className="font-medium">{exchange.itemReceived.title}</p>
                      </div>
                    </div>
                    
                    <Separator orientation="vertical" className="h-16" />
                    
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src={exchange.partnerAvatar} alt={exchange.partnerName} />
                        <AvatarFallback>{exchange.partnerName.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{exchange.partnerName}</p>
                        <p className="text-sm text-gray-600">
                          {new Date(exchange.date).toLocaleDateString('fr-FR')}
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="flex items-center gap-1 text-green-600">
                        <Leaf className="w-4 h-4" />
                        <span className="text-sm">{exchange.ecoImpact}kg CO₂</span>
                      </div>
                      <Badge className="mt-1 bg-green-100 text-green-800">
                        Terminé
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="pending" className="mt-6">
              <div className="space-y-4">
                {pendingExchanges.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Package className="w-12 h-12 mx-auto mb-2 text-gray-400" />
                    <p>Aucun échange en cours</p>
                  </div>
                ) : (
                  pendingExchanges.map((exchange) => (
                    <div key={exchange.id} className="flex items-center gap-4 p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center gap-3 flex-1">
                        <img 
                          src={exchange.itemOffered.image} 
                          alt={exchange.itemOffered.title}
                          className="w-16 h-16 rounded-lg object-cover"
                        />
                        <div className="flex-1">
                          <p className="font-medium">{exchange.itemOffered.title}</p>
                          <p className="text-sm text-gray-600">en échange de</p>
                          <p className="font-medium">{exchange.itemReceived.title}</p>
                        </div>
                      </div>
                      
                      <Separator orientation="vertical" className="h-16" />
                      
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={exchange.partnerAvatar} alt={exchange.partnerName} />
                          <AvatarFallback>{exchange.partnerName.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{exchange.partnerName}</p>
                          <p className="text-sm text-gray-600">
                            {new Date(exchange.date).toLocaleDateString('fr-FR')}
                          </p>
                        </div>
                      </div>

                      <Badge className="bg-amber-100 text-amber-800">
                        En cours
                      </Badge>
                    </div>
                  ))
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Impact Section */}
      <Card className="border-2 border-emerald-200 bg-gradient-to-br from-emerald-50 to-white">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Leaf className="w-5 h-5 text-emerald-600" />
            <CardTitle>Votre impact environnemental</CardTitle>
          </div>
          <CardDescription>
            Grâce à vos {stats.totalExchanges} échanges, vous avez économisé {stats.co2Saved}kg de CO₂
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-white rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Équivalent à</p>
              <p className="text-xl">{Math.round(stats.co2Saved / 2.3)} km en voiture</p>
            </div>
            <div className="p-4 bg-white rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Ou</p>
              <p className="text-xl">{Math.round(stats.co2Saved / 0.4)} repas végétariens</p>
            </div>
            <div className="p-4 bg-white rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Ou</p>
              <p className="text-xl">{Math.round(stats.co2Saved * 0.02)} arbres plantés</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
